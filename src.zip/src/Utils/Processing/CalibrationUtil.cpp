#include "CalibrationUtil.hpp"

CalibrationUtil::CalibrationUtil(int limit, cv::Size size, std::shared_ptr<ConcurrentStream<cv::Mat>> inputStream) : m_inputStream(inputStream), m_calibrator(size) {
	m_limit = limit;
	m_success = 0;
}

Calibrator CalibrationUtil::getCalib() {
	return m_calibrator;
}

void CalibrationUtil::update() {
	m_inputStream.read(m_data);
	if (m_limit < 1) {
		if (cv::waitKey(1) != -1) {
			if (!m_last) {
				if (m_calibrator.detect(m_data, true)) {
					++m_success;
				}
			} else {
				m_calibrator.detect(m_data, false);
			}
			m_last = true;
		} else {
			m_last = false;
		}
	} else {
		if (m_limit > m_success) {
			if (m_calibrator.detect(m_data, true)) {
				++m_success;
			} 
		} else {
			m_calibrator.detect(m_data, false);
		}
	}
	cv::imshow("Calibration", m_data);
}