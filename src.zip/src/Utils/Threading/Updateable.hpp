#pragma once
#ifndef UPDATEABLE_HPP
#define UPDATEABLE_HPP

class Updateable {
public:
	virtual void update() =0;
};

#endif 