#ifndef CALIBRATOR_HPP
#define CALIBRATOR_HPP

#include "Utils\Threading\ConcurrentStreamReader.hpp"
#include "Utils\Threading\ConcurrentStream.hpp"
#include <opencv2\opencv.hpp>

class Calibrator {
public:
	Calibrator(cv::Size size);
	bool detect(cv::Mat img, bool add);
	void calibrate();
	bool saveTo(char* filename) const;
	cv::Mat getIntrins();
	cv::Mat getDistCoeff();
	static bool loadFrom(char* filename, cv::Mat& intrinsic, cv::Mat& distCoeffs);
private:
	cv::Mat m_intrinsic;
	cv::Mat m_distCoeffs;
	cv::Size m_boardSize;
	cv::Size m_imgSize;
	std::vector<cv::Point2f> m_cornerPoints;
	std::vector<cv::Point3f> m_chessPoints;
	std::vector<std::vector<cv::Point3f>> m_objectPoints;
	std::vector<std::vector<cv::Point2f>> m_imagePoints;
};

#endif